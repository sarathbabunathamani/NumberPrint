package testcase;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import util.NumberPrintUtility;

public class TestNumberPrintUtility {

	String expectedResult="";
	String actualResult="";
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	//Positive Scenario - To test the conversion of number to roman with in Valid Range
	public void testConvertNumberToRoman_ValidRange() {
		int inputNumer=1326;
		String outputFormat="ROMAN";
		expectedResult="MCCCXXVI";
		actualResult=NumberPrintUtility.printNumberByFormat(inputNumer,outputFormat);
		Assert.assertEquals("Expected Result does not match with Actual Result", expectedResult,actualResult);
	}

	@Test
	//Negative Scenario - To test the conversion of number to roman using Invalid Range
	public void testConvertNumberToRoman_InvalidRange() {
		int inputNumer=5326;
		String outputFormat="ROMAN";
		expectedResult="Invalid Range of Number";
		actualResult=NumberPrintUtility.printNumberByFormat(inputNumer,outputFormat);
		Assert.assertEquals("Expected Result does not match with Actual Result", expectedResult,actualResult);
	}

	@Test
	//Negative Scenario - To test the conversion of number to roman using Invalid outputFormat
	public void testConvertNumberToRoman_InvalidFormat() {
		int inputNumer=2326;
		String outputFormat="SARATH";
		expectedResult="Invalid Output Format";
		actualResult=NumberPrintUtility.printNumberByFormat(inputNumer,outputFormat);
		Assert.assertEquals("Expected Result does not match with Actual Result", expectedResult,actualResult);
	}

	
	@Test
	//Positive Scenario - To test the conversion of number to WORDS with in Valid Range
	public void testConvertNumberToWords_ValidRange() {
		int inputNumer=3876;
		String outputFormat="WORDS";
		expectedResult="Three Thousand Eight hundered and Seventy Six ";
		actualResult=NumberPrintUtility.printNumberByFormat(inputNumer,outputFormat);
		Assert.assertEquals("Expected Result does not match with Actual Result", expectedResult,actualResult);
	}

	@Test
	//Negative Scenario - To test the conversion of number to WORDS using Invalid Range
	public void testConvertNumberToWords_InvalidRange() {
		int inputNumer=5326;
		String outputFormat="WORDS";
		expectedResult="Invalid Range of Number";
		actualResult=NumberPrintUtility.printNumberByFormat(inputNumer,outputFormat);
		Assert.assertEquals("Expected Result does not match with Actual Result", expectedResult,actualResult);
	}

	@Test
	//Negative Scenario - To test the conversion of number to WORDS using Invalid outputFormat
	public void testConvertNumberToWords_InvalidFormat() {
		int inputNumer=1675;
		String outputFormat="BABU";
		expectedResult="Invalid Output Format";
		actualResult=NumberPrintUtility.printNumberByFormat(inputNumer,outputFormat);
		Assert.assertEquals("Expected Result does not match with Actual Result", expectedResult,actualResult);
	}

	
	
	
	
}

