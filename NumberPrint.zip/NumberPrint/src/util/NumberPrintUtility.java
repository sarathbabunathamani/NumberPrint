package util;
/**
 * 
 * @author Sarathbabu
 * Date:21-Jan-2015
 * This class will convert integer to ROMAN Letter or in WORDS as per user request
 */
public class NumberPrintUtility {

	/**
	 * This method will convert Numeric value to Roman Letter
	 * @param input
	 * @return
	 */
	public static String convertNumberToRoman(int input) {
		
		String s = "";
		while (input >= 1000) {
			s += "M";
			input -= 1000;
		}
		while (input >= 900) {
			s += "CM";
			input -= 900;
		}
		while (input >= 500) {
			s += "D";
			input -= 500;
		}
		while (input >= 400) {
			s += "CD";
			input -= 400;
		}
		while (input >= 100) {
			s += "C";
			input -= 100;
		}
		while (input >= 90) {
			s += "XC";
			input -= 90;
		}
		while (input >= 50) {
			s += "L";
			input -= 50;
		}
		while (input >= 40) {
			s += "XL";
			input -= 40;
		}
		while (input >= 10) {
			s += "X";
			input -= 10;
		}
		while (input >= 9) {
			s += "IX";
			input -= 9;
		}
		while (input >= 5) {
			s += "V";
			input -= 5;
		}
		while (input >= 4) {
			s += "IV";
			input -= 4;
		}
		while (input >= 1) {
			s += "I";
			input -= 1;
		}
		return s;
	}

	
	/**
	 * This method will convert number in to WORDS.
	 * @param number
	 * @return
	 */
	public static String convertNumberToWords(int number){
		
	    int size=String.valueOf(number).length();
	    StringBuffer sb= new StringBuffer();
	    
	    if(size == 4){
		
	    		//Seperate number into digits.
				int digit4 = number%10;
				number = number/10;
				int digit3 = number%10;
				number = number/10;
				int digit2 = number%10;
				number = number/10;
				int digit1 = number%10;
				number = number/10;
				
				//Set up a switch statement to read through the number.
				switch (digit1)
				{
				case 1: sb.append("One Thousand ");break;
				case 2: sb.append("Two Thousand "); break;
				case 3: sb.append("Three Thousand "); break;
				case 4: sb.append("Four Thousand "); break;
				case 5: sb.append("Five Thousand "); break;
				case 6: sb.append("Six Thousand "); break;
				case 7: sb.append("Seven Thousand "); break;
				case 8: sb.append("Eight Thousand "); break;
				case 9: sb.append("Nine Thousand "); break;
				case 0: sb.append("Zero Thousand "); break;
				default: sb.append(""); break;
				}
				switch (digit2)
				{
				case 1: sb.append("One hundered and ");break;
				case 2: sb.append("Two hundered and "); break;
				case 3: sb.append("Three hundered and "); break;
				case 4: sb.append("Four hundered and "); break;
				case 5: sb.append("Five hundered and "); break;
				case 6: sb.append("Six hundered and "); break;
				case 7: sb.append("Seven hundered and "); break;
				case 8: sb.append("Eight hundered and "); break;
				case 9: sb.append("Nine hundered and "); break;
				case 0: sb.append("Zero hundered and "); break;
				default: sb.append(""); break;
				}
				switch (digit3)
				{
				case 1: sb.append("One ");break;
				case 2: sb.append("Twenty "); break;
				case 3: sb.append("Thirty "); break;
				case 4: sb.append("Fourty "); break;
				case 5: sb.append("Fivty "); break;
				case 6: sb.append("Sixty "); break;
				case 7: sb.append("Seventy "); break;
				case 8: sb.append("Eighty "); break;
				case 9: sb.append("Ninty "); break;
				case 0: sb.append("Zero "); break;
				default: sb.append(""); break;
				}
				switch (digit4)
				{
				case 1: sb.append("One ");break;
				case 2: sb.append("Two "); break;
				case 3: sb.append("Three "); break;
				case 4: sb.append("Four "); break;
				case 5: sb.append("Five "); break;
				case 6: sb.append("Six "); break;
				case 7: sb.append("Seven "); break;
				case 8: sb.append("Eight "); break;
				case 9: sb.append("Nine "); break;
				case 0: sb.append("Zero "); break;
				default: sb.append(""); break;
				}
	    }else if(size == 3){
	    	
	    	int digit3 = number%10;
			number = number/10;
			int digit2 = number%10;
			number = number/10;
			int digit1 = number%10;
			number = number/10;
			
			//Set up a switch statement to read through the number.
			switch (digit1)
			{
			case 1: sb.append("One hundered and ");break;
			case 2: sb.append("Two hundered and "); break;
			case 3: sb.append("Three hundered and "); break;
			case 4: sb.append("Four hundered and "); break;
			case 5: sb.append("Five hundered and "); break;
			case 6: sb.append("Six hundered and "); break;
			case 7: sb.append("Seven hundered and "); break;
			case 8: sb.append("Eight hundered and "); break;
			case 9: sb.append("Nine hundered and "); break;
			case 0: sb.append("Zero hundered and "); break;
			default: sb.append(""); break;
			}
			switch (digit2)
			{
			case 1: sb.append("One ");break;
			case 2: sb.append("Twenty "); break;
			case 3: sb.append("Thirty "); break;
			case 4: sb.append("Fourty "); break;
			case 5: sb.append("Fivty "); break;
			case 6: sb.append("Sixty "); break;
			case 7: sb.append("Seventy "); break;
			case 8: sb.append("Eighty "); break;
			case 9: sb.append("Ninty "); break;
			case 0: sb.append("Zero "); break;
			default: sb.append(""); break;
			}
			switch (digit3)
			{
			case 1: sb.append("One ");break;
			case 2: sb.append("Two "); break;
			case 3: sb.append("Three "); break;
			case 4: sb.append("Four "); break;
			case 5: sb.append("Five "); break;
			case 6: sb.append("Six "); break;
			case 7: sb.append("Seven "); break;
			case 8: sb.append("Eight "); break;
			case 9: sb.append("Nine "); break;
			case 0: sb.append("Zero "); break;
			default: sb.append(""); break;
			}
	    }else if(size == 2){
	    	int digit2 = number%10;
			number = number/10;
			int digit1 = number%10;
			number = number/10;
			
			switch (digit1)
			{
			case 1: sb.append("One ");break;
			case 2: sb.append("Twenty "); break;
			case 3: sb.append("Thirty "); break;
			case 4: sb.append("Fourty "); break;
			case 5: sb.append("Fivty "); break;
			case 6: sb.append("Sixty "); break;
			case 7: sb.append("Seventy "); break;
			case 8: sb.append("Eighty "); break;
			case 9: sb.append("Ninty "); break;
			case 0: sb.append("Zero "); break;
			default: sb.append(""); break;
			}
			switch (digit2)
			{
			case 1: sb.append("One ");break;
			case 2: sb.append("Two "); break;
			case 3: sb.append("Three "); break;
			case 4: sb.append("Four "); break;
			case 5: sb.append("Five "); break;
			case 6: sb.append("Six "); break;
			case 7: sb.append("Seven "); break;
			case 8: sb.append("Eight "); break;
			case 9: sb.append("Nine "); break;
			case 0: sb.append("Zero "); break;
			default: sb.append(""); break;
			}
	    }else if(size == 1){
	    	int digit1 = number%10;
			number = number/10;
			
			switch (digit1)
			{
			case 1: sb.append("One ");break;
			case 2: sb.append("Two "); break;
			case 3: sb.append("Three "); break;
			case 4: sb.append("Four "); break;
			case 5: sb.append("Five "); break;
			case 6: sb.append("Six "); break;
			case 7: sb.append("Seven "); break;
			case 8: sb.append("Eight "); break;
			case 9: sb.append("Nine "); break;
			case 0: sb.append("Zero "); break;
			default: sb.append(""); break;
			}
	    }
		String result=sb.toString();
		return result;
		
	}
	
	/**
	 * This will convert number to either Roman letters or WORDS 
	 * if the number is in the range of 1 to 3999
	 * @param inputNumber - Number which needs to convert
	 * @param outputFormat- Output Format in which number needs to convert
	 * @return
	 */
	public static String printNumberByFormat(int inputNumber,String outputFormat){
		String result="";
		
		if (inputNumber < 1 || inputNumber > 3999)
			return "Invalid Range of Number";
		
		
		if("ROMAN".equalsIgnoreCase(outputFormat)){
			result=convertNumberToRoman(inputNumber);
		}else if("WORDS".equalsIgnoreCase(outputFormat)){
			result=convertNumberToWords(inputNumber);
		}else{
			return "Invalid Output Format";
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("result:::"+printNumberByFormat(1974, "ROMAN"));
		System.out.println("result:::"+printNumberByFormat(1328, "WORDS"));
	}

}
